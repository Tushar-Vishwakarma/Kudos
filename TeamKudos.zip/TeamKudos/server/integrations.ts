import { z } from "zod";
import { handleSlackSlashCommand } from "./slack";
import { handleTeamsCommand } from "./teams";

// Validate Slack slash command payload
const slackCommandSchema = z.object({
  token: z.string(),
  team_id: z.string(),
  team_domain: z.string(),
  channel_id: z.string(),
  channel_name: z.string(),
  user_id: z.string(),
  user_name: z.string(),
  command: z.string(),
  text: z.string(),
  response_url: z.string(),
  trigger_id: z.string().optional(),
}).partial();

// Validate Teams command payload
const teamsCommandSchema = z.object({
  text: z.string(),
  from: z.object({
    user: z.object({
      id: z.string(),
      displayName: z.string(),
    }),
  }),
  channelId: z.string().optional(),
});

// Handle webhook requests from integrations
export async function handleWebhook(
  platform: "slack" | "teams",
  body: any
): Promise<any> {
  try {
    switch (platform) {
      case "slack":
        const slackPayload = slackCommandSchema.parse(body);
        return await handleSlackSlashCommand(slackPayload);

      case "teams":
        const teamsPayload = teamsCommandSchema.parse(body);
        return await handleTeamsCommand(teamsPayload);

      default:
        throw new Error(`Unsupported platform: ${platform}`);
    }
  } catch (error) {
    console.error(`Error handling ${platform} webhook:`, error);
    return {
      text: "Sorry, something went wrong processing your request.",
    };
  }
}
