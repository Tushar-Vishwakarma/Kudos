import type { Express, Request, Response } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { 
  insertKudosSchema,
  insertKudosValueSchema,
  insertReactionSchema
} from "@shared/schema";
import { z } from "zod";
import { handleWebhook } from "./integrations";
import { sendKudosToSlackChannel } from "./slack";

export async function registerRoutes(app: Express): Promise<Server> {
  // API Routes
  const apiRouter = app.route("/api");

  // Users
  app.get("/api/users", async (_req: Request, res: Response) => {
    const users = await storage.listUsers();
    res.json(users);
  });

  app.get("/api/users/:id", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    const user = await storage.getUser(userId);
    if (!user) {
      return res.status(404).json({ message: "User not found" });
    }

    res.json(user);
  });

  // Values (for tagging kudos)
  app.get("/api/values", async (_req: Request, res: Response) => {
    const values = await storage.listValues();
    res.json(values);
  });

  // Badges
  app.get("/api/badges", async (_req: Request, res: Response) => {
    const badges = await storage.listBadges();
    res.json(badges);
  });

  // User Badges
  app.get("/api/users/:id/badges", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    const userBadges = await storage.getUserBadges(userId);
    res.json(userBadges);
  });

  // Kudos
  app.get("/api/kudos/recent", async (req: Request, res: Response) => {
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    const isPublic = req.query.public !== "false"; // Default to true
    
    const kudos = await storage.listRecentKudosWithDetails(limit, isPublic);
    res.json(kudos);
  });

  app.get("/api/kudos/:id", async (req: Request, res: Response) => {
    const kudosId = parseInt(req.params.id);
    if (isNaN(kudosId)) {
      return res.status(400).json({ message: "Invalid kudos ID" });
    }

    const kudos = await storage.getKudosWithDetails(kudosId);
    if (!kudos) {
      return res.status(404).json({ message: "Kudos not found" });
    }

    res.json(kudos);
  });

  app.post("/api/kudos", async (req: Request, res: Response) => {
    try {
      const { kudos, valueIds } = req.body;
      
      // Validate kudos data
      const validatedKudos = insertKudosSchema.parse({
        ...kudos,
        platform: "app"
      });
      
      // Create kudos
      const createdKudos = await storage.createKudos(validatedKudos);
      
      // Add values
      if (valueIds && Array.isArray(valueIds)) {
        for (const valueId of valueIds) {
          const kudosValue = {
            kudosId: createdKudos.id,
            valueId: valueId
          };
          
          const validatedKudosValue = insertKudosValueSchema.parse(kudosValue);
          await storage.createKudosValue(validatedKudosValue);
        }
      }
      
      // If Slack integration is enabled, send to Slack channel
      if (process.env.SLACK_BOT_TOKEN && process.env.SLACK_CHANNEL_ID) {
        await sendKudosToSlackChannel(createdKudos.id);
      }
      
      const kudosWithDetails = await storage.getKudosWithDetails(createdKudos.id);
      
      res.status(201).json(kudosWithDetails);
    } catch (error) {
      console.error("Error creating kudos:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid kudos data", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to create kudos" });
    }
  });

  // User Received Kudos
  app.get("/api/users/:id/kudos/received", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    const kudos = await storage.listUserReceivedKudos(userId);
    res.json(kudos);
  });

  // User Given Kudos
  app.get("/api/users/:id/kudos/given", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    const kudos = await storage.listUserGivenKudos(userId);
    res.json(kudos);
  });

  // Reactions
  app.post("/api/kudos/:id/react", async (req: Request, res: Response) => {
    try {
      const kudosId = parseInt(req.params.id);
      if (isNaN(kudosId)) {
        return res.status(400).json({ message: "Invalid kudos ID" });
      }
      
      const { userId, type } = req.body;
      
      const reactionData = {
        kudosId,
        userId,
        type
      };
      
      const validatedReaction = insertReactionSchema.parse(reactionData);
      const reaction = await storage.createReaction(validatedReaction);
      
      const reactionCounts = await storage.getReactionCounts(kudosId);
      
      res.status(201).json({ reaction, counts: reactionCounts });
    } catch (error) {
      console.error("Error creating reaction:", error);
      
      if (error instanceof z.ZodError) {
        return res.status(400).json({ message: "Invalid reaction data", errors: error.errors });
      }
      
      res.status(500).json({ message: "Failed to create reaction" });
    }
  });

  // Leaderboard
  app.get("/api/leaderboard", async (req: Request, res: Response) => {
    const period = (req.query.period as "weekly" | "monthly" | "all-time") || "monthly";
    const limit = req.query.limit ? parseInt(req.query.limit as string) : 10;
    
    const leaderboard = await storage.getLeaderboard(period, limit);
    res.json(leaderboard);
  });

  // User stats for dashboard
  app.get("/api/users/:id/stats", async (req: Request, res: Response) => {
    const userId = parseInt(req.params.id);
    if (isNaN(userId)) {
      return res.status(400).json({ message: "Invalid user ID" });
    }

    const stats = await storage.getUserStats(userId);
    res.json(stats);
  });

  // Team engagement
  app.get("/api/team/engagement", async (_req: Request, res: Response) => {
    const engagement = await storage.getTeamEngagement();
    res.json({ engagement });
  });

  // Simplified Slack verification endpoints
  app.get("/api/slack/events", (req: Request, res: Response) => {
    console.log("Received GET request to Slack events endpoint");
    return res.send("Slack events endpoint is working");
  });
  
  app.post("/api/slack/events", (req: Request, res: Response) => {
    console.log("Received Slack event request");
    console.log("Request headers:", req.headers);
    console.log("Request body:", req.body);
    
    // Handle all responses with 200 OK status
    return res.status(200).json(req.body || {});
  });

  // Integration webhooks
  app.post("/api/integrations/slack/command", async (req: Request, res: Response) => {
    try {
      console.log("Received Slack command request body:", req.body);
      console.log("Request headers:", req.headers);
      
      // Special handling for Slack's token verification
      if (req.body.ssl_check) {
        return res.status(200).end();
      }
      
      // Special handling for empty requests (Slack verification)
      if (!req.body.text && !req.body.command) {
        return res.status(200).end();
      }
      
      const response = await handleWebhook("slack", req.body);
      
      // Return response in the format Slack expects
      res.setHeader('Content-Type', 'application/json');
      return res.json(response);
    } catch (error) {
      console.error("Error handling Slack webhook:", error);
      console.error("Request body:", req.body);
      return res.status(200).json({ 
        text: "An error occurred processing your request. Please try again.",
        response_type: "ephemeral"
      });
    }
  });

  app.post("/api/integrations/teams/command", async (req: Request, res: Response) => {
    try {
      const response = await handleWebhook("teams", req.body);
      res.json(response);
    } catch (error) {
      console.error("Error handling Teams webhook:", error);
      res.status(500).json({ text: "An error occurred processing your request" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
