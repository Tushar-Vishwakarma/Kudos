import { storage } from "./storage";
import { insertKudosSchema, insertKudosValueSchema } from "@shared/schema";

// Similar structure to the Slack integration but for Microsoft Teams
// This is a simplified version for the prototype

if (process.env.NODE_ENV === "production" && !process.env.TEAMS_BOT_APP_ID) {
  console.warn("Warning: TEAMS_BOT_APP_ID environment variable is not set. Teams integration will not work.");
}

if (process.env.NODE_ENV === "production" && !process.env.TEAMS_CHANNEL_ID) {
  console.warn("Warning: TEAMS_CHANNEL_ID environment variable is not set. Teams kudos will not be posted to a channel.");
}

/**
 * Parse a Teams kudos message and extract the username and message
 * Format: /kudos @username message #value1 #value2
 */
export async function parseTeamsKudos(
  text: string,
  fromUsername: string
): Promise<{
  toUsername: string;
  message: string;
  valueNames: string[];
  success: boolean;
  error?: string;
}> {
  try {
    // Extract the recipient username (with @ symbol)
    const usernameMatch = text.match(/@(\w+)/);
    if (!usernameMatch) {
      return {
        toUsername: "",
        message: "",
        valueNames: [],
        success: false,
        error: "No recipient specified. Use format: /kudos @username message #value1 #value2",
      };
    }

    const toUsername = usernameMatch[1]; // Get the username without @
    
    // Extract hashtags for values
    const valueMatches = text.match(/#(\w+)/g) || [];
    const valueNames = valueMatches.map(tag => tag.substring(1)); // Remove # prefix
    
    // Remove the @username and #values from the text to get the message
    let message = text.replace(/@\w+/, "").trim();
    valueMatches.forEach(tag => {
      message = message.replace(tag, "").trim();
    });
    
    // Check if the sender is trying to give kudos to themselves
    if (toUsername === fromUsername) {
      return {
        toUsername: "",
        message: "",
        valueNames: [],
        success: false,
        error: "You cannot give kudos to yourself.",
      };
    }
    
    // Check if the message is not empty
    if (!message) {
      return {
        toUsername: "",
        message: "",
        valueNames: [],
        success: false,
        error: "Please include a message with your kudos.",
      };
    }

    return {
      toUsername,
      message,
      valueNames,
      success: true,
    };
  } catch (error) {
    console.error("Error parsing Teams kudos:", error);
    return {
      toUsername: "",
      message: "",
      valueNames: [],
      success: false,
      error: "Failed to parse your kudos. Please use format: /kudos @username message #value1 #value2",
    };
  }
}

/**
 * Process a kudos message from Teams and save it to the database
 */
export async function processTeamsKudos(
  text: string,
  fromUsername: string
): Promise<{
  success: boolean;
  message: string;
  kudosId?: number;
}> {
  try {
    const { toUsername, message, valueNames, success, error } = await parseTeamsKudos(text, fromUsername);
    
    if (!success) {
      return { success: false, message: error || "Failed to parse kudos" };
    }
    
    // Get or create the users
    const fromUser = await storage.getUserByUsername(fromUsername);
    const toUser = await storage.getUserByUsername(toUsername);
    
    if (!fromUser) {
      return { success: false, message: "Your user account is not registered in KudosConnect." };
    }
    
    if (!toUser) {
      return { success: false, message: `User @${toUsername} is not registered in KudosConnect.` };
    }
    
    // Create the kudos
    const kudosData = {
      fromUserId: fromUser.id,
      toUserId: toUser.id,
      message,
      isPublic: true,
      platform: "teams",
    };
    
    // Validate the kudos data
    const validatedData = insertKudosSchema.parse(kudosData);
    
    // Create the kudos
    const kudos = await storage.createKudos(validatedData);
    
    // Add values to the kudos
    for (const valueName of valueNames) {
      const value = await storage.getValueByName(valueName);
      if (value) {
        const kudosValue = {
          kudosId: kudos.id,
          valueId: value.id,
        };
        
        const validatedKudosValue = insertKudosValueSchema.parse(kudosValue);
        await storage.createKudosValue(validatedKudosValue);
      }
    }
    
    return {
      success: true,
      message: `Kudos from @${fromUser.username} to @${toUser.username} saved successfully!`,
      kudosId: kudos.id,
    };
  } catch (error) {
    console.error("Error processing Teams kudos:", error);
    return { success: false, message: "An error occurred while processing your kudos." };
  }
}

/**
 * Handle a Teams message for the bot
 * This is a simplified implementation for the prototype
 */
export async function handleTeamsCommand(body: any): Promise<{ text: string }> {
  try {
    const { text, from } = body;
    
    // Simple extraction of the command
    if (!text.startsWith("/kudos")) {
      return { text: "Use /kudos @username message #value1 #value2 to give kudos" };
    }
    
    const kudosText = text.substring("/kudos".length).trim();
    const result = await processTeamsKudos(kudosText, from.user.displayName);
    
    return { text: result.message };
  } catch (error) {
    console.error("Error handling Teams command:", error);
    return { text: "An error occurred while processing your request." };
  }
}
