import {
  User,
  InsertUser,
  Value,
  InsertValue,
  Badge,
  InsertBadge,
  UserBadge,
  InsertUserBadge,
  Kudos,
  InsertKudos,
  KudosValue,
  InsertKudosValue,
  Reaction,
  InsertReaction,
} from "@shared/schema";

// Storage interface
export interface IStorage {
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  listUsers(): Promise<User[]>;

  // Value methods
  getValue(id: number): Promise<Value | undefined>;
  getValueByName(name: string): Promise<Value | undefined>;
  createValue(value: InsertValue): Promise<Value>;
  listValues(): Promise<Value[]>;

  // Badge methods
  getBadge(id: number): Promise<Badge | undefined>;
  createBadge(badge: InsertBadge): Promise<Badge>;
  listBadges(): Promise<Badge[]>;

  // User Badge methods
  getUserBadges(userId: number): Promise<(UserBadge & { badge: Badge })[]>;
  createUserBadge(userBadge: InsertUserBadge): Promise<UserBadge>;
  updateUserBadgeLevel(userBadgeId: number, level: number): Promise<UserBadge>;

  // Kudos methods
  getKudos(id: number): Promise<Kudos | undefined>;
  createKudos(kudos: InsertKudos): Promise<Kudos>;
  listRecentKudos(limit?: number, isPublic?: boolean): Promise<Kudos[]>;
  listUserReceivedKudos(userId: number): Promise<Kudos[]>;
  listUserGivenKudos(userId: number): Promise<Kudos[]>;
  getKudosWithDetails(kudosId: number): Promise<KudosWithDetails | undefined>;
  listRecentKudosWithDetails(limit?: number, isPublic?: boolean): Promise<KudosWithDetails[]>;

  // Kudos Value methods
  createKudosValue(kudosValue: InsertKudosValue): Promise<KudosValue>;
  getKudosValues(kudosId: number): Promise<Value[]>;

  // Reaction methods
  createReaction(reaction: InsertReaction): Promise<Reaction>;
  deleteReaction(id: number): Promise<boolean>;
  listKudosReactions(kudosId: number): Promise<Reaction[]>;
  getReactionCounts(kudosId: number): Promise<Record<string, number>>;

  // Leaderboard methods
  getLeaderboard(
    period?: "weekly" | "monthly" | "all-time",
    limit?: number
  ): Promise<LeaderboardEntry[]>;

  // Dashboard data
  getUserStats(userId: number): Promise<UserStats>;
  getTeamEngagement(): Promise<number>; // percentage
}

// Combined types for returning data
export type KudosWithDetails = Kudos & {
  fromUser: User;
  toUser: User;
  values: Value[];
  reactions: Record<string, number>;
};

export type LeaderboardEntry = {
  user: User;
  kudosCount: number;
  topValues: { value: Value; count: number }[];
};

export type UserStats = {
  kudosReceived: number;
  kudosGiven: number;
  badgesEarned: number;
  receivedTrend: number; // percentage change from last period
  givenTrend: number; // percentage change from last period
  badgesTrend: number; // percentage change from last period
};

// In-memory storage implementation
export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private values: Map<number, Value>;
  private badges: Map<number, Badge>;
  private userBadges: Map<number, UserBadge>;
  private kudos: Map<number, Kudos>;
  private kudosValues: Map<number, KudosValue>;
  private reactions: Map<number, Reaction>;
  
  // Auto-increment IDs
  private currentUserId: number;
  private currentValueId: number;
  private currentBadgeId: number;
  private currentUserBadgeId: number;
  private currentKudosId: number;
  private currentKudosValueId: number;
  private currentReactionId: number;

  constructor() {
    this.users = new Map();
    this.values = new Map();
    this.badges = new Map();
    this.userBadges = new Map();
    this.kudos = new Map();
    this.kudosValues = new Map();
    this.reactions = new Map();
    
    this.currentUserId = 1;
    this.currentValueId = 1;
    this.currentBadgeId = 1;
    this.currentUserBadgeId = 1;
    this.currentKudosId = 1;
    this.currentKudosValueId = 1;
    this.currentReactionId = 1;

    // Initialize with demo data
    this.initializeDemoData();
  }

  private initializeDemoData() {
    // Add sample values
    const valueData: InsertValue[] = [
      { name: "Teamwork", description: "Collaborating effectively with others", icon: "users", colorClass: "blue" },
      { name: "Innovation", description: "Bringing creative ideas to the table", icon: "lightbulb", colorClass: "purple" },
      { name: "Problem Solver", description: "Finding solutions to complex issues", icon: "tools", colorClass: "yellow" },
      { name: "Excellence", description: "Going above and beyond expectations", icon: "rocket", colorClass: "green" },
      { name: "Customer Focus", description: "Putting the customer first", icon: "heart", colorClass: "pink" },
      { name: "Leadership", description: "Guiding and inspiring others", icon: "crown", colorClass: "orange" },
      { name: "Creativity", description: "Thinking outside the box", icon: "palette", colorClass: "green" },
    ];
    
    valueData.forEach(val => this.createValue(val));

    // Add sample badges
    const badgeData: InsertBadge[] = [
      { name: "Team Player", description: "Recognized for teamwork", icon: "users", colorClass: "blue", requiredKudos: 5 },
      { name: "Innovator", description: "Recognized for innovative ideas", icon: "lightbulb", colorClass: "purple", requiredKudos: 5 },
      { name: "Problem Solver", description: "Recognized for solving problems", icon: "tools", colorClass: "yellow", requiredKudos: 5 },
      { name: "Go-Getter", description: "Recognized for excellence and initiative", icon: "rocket", colorClass: "green", requiredKudos: 5 },
      { name: "Customer Champion", description: "Recognized for customer focus", icon: "heart", colorClass: "pink", requiredKudos: 5 },
      { name: "Leader", description: "Recognized for leadership", icon: "crown", colorClass: "orange", requiredKudos: 5 },
      { name: "Creative Genius", description: "Recognized for creativity", icon: "palette", colorClass: "green", requiredKudos: 5 },
    ];
    
    badgeData.forEach(badge => this.createBadge(badge));

    // Add sample users
    const userData: InsertUser[] = [
      { username: "sarah.chen", displayName: "Sarah Chen", department: "Engineering", avatarUrl: "https://randomuser.me/api/portraits/women/17.jpg" },
      { username: "miguel.rodriguez", displayName: "Miguel Rodriguez", department: "Engineering", avatarUrl: "https://randomuser.me/api/portraits/men/69.jpg" },
      { username: "alex.morgan", displayName: "Alex Morgan", department: "Product", avatarUrl: "https://randomuser.me/api/portraits/men/23.jpg", isAdmin: true },
      { username: "jasmine.lee", displayName: "Jasmine Lee", department: "Design", avatarUrl: "https://randomuser.me/api/portraits/women/32.jpg" },
      { username: "thomas.wright", displayName: "Thomas Wright", department: "Marketing", avatarUrl: "https://randomuser.me/api/portraits/men/86.jpg" },
      { username: "lisa.johnson", displayName: "Lisa Johnson", department: "Marketing", avatarUrl: "https://randomuser.me/api/portraits/women/46.jpg" },
    ];
    
    userData.forEach(user => this.createUser(user));
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username
    );
  }

  async createUser(user: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const newUser: User = { ...user, id };
    this.users.set(id, newUser);
    return newUser;
  }

  async listUsers(): Promise<User[]> {
    return Array.from(this.users.values());
  }

  // Value methods
  async getValue(id: number): Promise<Value | undefined> {
    return this.values.get(id);
  }

  async getValueByName(name: string): Promise<Value | undefined> {
    return Array.from(this.values.values()).find(
      (value) => value.name === name
    );
  }

  async createValue(value: InsertValue): Promise<Value> {
    const id = this.currentValueId++;
    const newValue: Value = { ...value, id };
    this.values.set(id, newValue);
    return newValue;
  }

  async listValues(): Promise<Value[]> {
    return Array.from(this.values.values());
  }

  // Badge methods
  async getBadge(id: number): Promise<Badge | undefined> {
    return this.badges.get(id);
  }

  async createBadge(badge: InsertBadge): Promise<Badge> {
    const id = this.currentBadgeId++;
    const newBadge: Badge = { ...badge, id };
    this.badges.set(id, newBadge);
    return newBadge;
  }

  async listBadges(): Promise<Badge[]> {
    return Array.from(this.badges.values());
  }

  // User Badge methods
  async getUserBadges(userId: number): Promise<(UserBadge & { badge: Badge })[]> {
    const userBadgesList = Array.from(this.userBadges.values()).filter(
      (userBadge) => userBadge.userId === userId
    );
    
    return userBadgesList.map(userBadge => {
      const badge = this.badges.get(userBadge.badgeId);
      if (!badge) {
        throw new Error(`Badge with ID ${userBadge.badgeId} not found`);
      }
      return { ...userBadge, badge };
    });
  }

  async createUserBadge(userBadge: InsertUserBadge): Promise<UserBadge> {
    const id = this.currentUserBadgeId++;
    const now = new Date();
    const newUserBadge: UserBadge = { ...userBadge, id, earnedAt: now };
    this.userBadges.set(id, newUserBadge);
    return newUserBadge;
  }

  async updateUserBadgeLevel(userBadgeId: number, level: number): Promise<UserBadge> {
    const userBadge = this.userBadges.get(userBadgeId);
    if (!userBadge) {
      throw new Error(`User badge with ID ${userBadgeId} not found`);
    }
    
    const updatedUserBadge: UserBadge = { ...userBadge, level };
    this.userBadges.set(userBadgeId, updatedUserBadge);
    return updatedUserBadge;
  }

  // Kudos methods
  async getKudos(id: number): Promise<Kudos | undefined> {
    return this.kudos.get(id);
  }

  async createKudos(kudos: InsertKudos): Promise<Kudos> {
    const id = this.currentKudosId++;
    const now = new Date();
    const newKudos: Kudos = { ...kudos, id, createdAt: now };
    this.kudos.set(id, newKudos);
    
    // Check if user should earn badges based on received kudos
    this.checkAndAwardBadges(kudos.toUserId);
    
    return newKudos;
  }

  private async checkAndAwardBadges(userId: number) {
    // Get all kudos received by this user
    const userKudos = await this.listUserReceivedKudos(userId);
    
    // Get all values from these kudos
    const valueCountMap: Record<number, number> = {};
    
    for (const kudos of userKudos) {
      const values = await this.getKudosValues(kudos.id);
      values.forEach(value => {
        valueCountMap[value.id] = (valueCountMap[value.id] || 0) + 1;
      });
    }
    
    // Get all badges
    const badges = await this.listBadges();
    
    // Get user's current badges
    const userBadges = await this.getUserBadges(userId);
    const userBadgeMap = new Map(userBadges.map(ub => [ub.badgeId, ub]));
    
    // Check each badge to see if user qualifies
    for (const badge of badges) {
      // Find a value with the same name as the badge (simplified mapping)
      const matchingValue = Array.from(this.values.values()).find(
        v => v.name.toLowerCase().includes(badge.name.toLowerCase()) || 
             badge.name.toLowerCase().includes(v.name.toLowerCase())
      );
      
      if (matchingValue) {
        const valueCount = valueCountMap[matchingValue.id] || 0;
        
        // Check if user has enough kudos with this value to earn the badge
        if (valueCount >= badge.requiredKudos) {
          // Calculate badge level (1 for minimum, +1 for each additional set)
          const level = Math.floor(valueCount / badge.requiredKudos);
          
          // Check if user already has this badge
          const existingBadge = userBadgeMap.get(badge.id);
          
          if (!existingBadge) {
            // Award new badge
            await this.createUserBadge({
              userId,
              badgeId: badge.id,
              level
            });
          } else if (existingBadge.level < level) {
            // Upgrade badge level
            await this.updateUserBadgeLevel(existingBadge.id, level);
          }
        }
      }
    }
  }

  async listRecentKudos(limit: number = 10, isPublic: boolean = true): Promise<Kudos[]> {
    return Array.from(this.kudos.values())
      .filter(kudos => isPublic ? kudos.isPublic : true)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime())
      .slice(0, limit);
  }

  async listUserReceivedKudos(userId: number): Promise<Kudos[]> {
    return Array.from(this.kudos.values())
      .filter(kudos => kudos.toUserId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async listUserGivenKudos(userId: number): Promise<Kudos[]> {
    return Array.from(this.kudos.values())
      .filter(kudos => kudos.fromUserId === userId)
      .sort((a, b) => b.createdAt.getTime() - a.createdAt.getTime());
  }

  async getKudosWithDetails(kudosId: number): Promise<KudosWithDetails | undefined> {
    const kudos = await this.getKudos(kudosId);
    if (!kudos) return undefined;
    
    const fromUser = await this.getUser(kudos.fromUserId);
    const toUser = await this.getUser(kudos.toUserId);
    
    if (!fromUser || !toUser) return undefined;
    
    const values = await this.getKudosValues(kudosId);
    const reactions = await this.getReactionCounts(kudosId);
    
    return {
      ...kudos,
      fromUser,
      toUser,
      values,
      reactions
    };
  }

  async listRecentKudosWithDetails(limit: number = 10, isPublic: boolean = true): Promise<KudosWithDetails[]> {
    const recentKudos = await this.listRecentKudos(limit, isPublic);
    const kudosWithDetails: KudosWithDetails[] = [];
    
    for (const kudos of recentKudos) {
      const details = await this.getKudosWithDetails(kudos.id);
      if (details) {
        kudosWithDetails.push(details);
      }
    }
    
    return kudosWithDetails;
  }

  // Kudos Value methods
  async createKudosValue(kudosValue: InsertKudosValue): Promise<KudosValue> {
    const id = this.currentKudosValueId++;
    const newKudosValue: KudosValue = { ...kudosValue, id };
    this.kudosValues.set(id, newKudosValue);
    return newKudosValue;
  }

  async getKudosValues(kudosId: number): Promise<Value[]> {
    const kudosValueEntries = Array.from(this.kudosValues.values())
      .filter(kv => kv.kudosId === kudosId);
    
    const values: Value[] = [];
    for (const kv of kudosValueEntries) {
      const value = this.values.get(kv.valueId);
      if (value) {
        values.push(value);
      }
    }
    
    return values;
  }

  // Reaction methods
  async createReaction(reaction: InsertReaction): Promise<Reaction> {
    // Check if user already reacted with the same type
    const existingReaction = Array.from(this.reactions.values()).find(
      r => r.kudosId === reaction.kudosId && r.userId === reaction.userId && r.type === reaction.type
    );
    
    if (existingReaction) {
      return existingReaction;
    }
    
    const id = this.currentReactionId++;
    const newReaction: Reaction = { ...reaction, id };
    this.reactions.set(id, newReaction);
    return newReaction;
  }

  async deleteReaction(id: number): Promise<boolean> {
    return this.reactions.delete(id);
  }

  async listKudosReactions(kudosId: number): Promise<Reaction[]> {
    return Array.from(this.reactions.values())
      .filter(reaction => reaction.kudosId === kudosId);
  }

  async getReactionCounts(kudosId: number): Promise<Record<string, number>> {
    const reactions = await this.listKudosReactions(kudosId);
    const counts: Record<string, number> = {};
    
    reactions.forEach(reaction => {
      counts[reaction.type] = (counts[reaction.type] || 0) + 1;
    });
    
    return counts;
  }

  // Leaderboard methods
  async getLeaderboard(
    period: "weekly" | "monthly" | "all-time" = "monthly",
    limit: number = 5
  ): Promise<LeaderboardEntry[]> {
    const users = await this.listUsers();
    const allKudos = Array.from(this.kudos.values());
    
    // Filter kudos by period
    const now = new Date();
    const filteredKudos = allKudos.filter(kudos => {
      if (period === "all-time") return true;
      
      const kudosDate = kudos.createdAt;
      const diffTime = Math.abs(now.getTime() - kudosDate.getTime());
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
      
      return period === "weekly" ? diffDays <= 7 : diffDays <= 30;
    });
    
    // Count kudos received per user
    const userKudosCounts: Record<number, number> = {};
    users.forEach(user => {
      userKudosCounts[user.id] = 0;
    });
    
    filteredKudos.forEach(kudos => {
      userKudosCounts[kudos.toUserId] = (userKudosCounts[kudos.toUserId] || 0) + 1;
    });
    
    // Get top values for each user
    const userTopValues: Record<number, Record<number, number>> = {};
    
    for (const kudos of filteredKudos) {
      if (!userTopValues[kudos.toUserId]) {
        userTopValues[kudos.toUserId] = {};
      }
      
      const kudosValues = await this.getKudosValues(kudos.id);
      kudosValues.forEach(value => {
        userTopValues[kudos.toUserId][value.id] = (userTopValues[kudos.toUserId][value.id] || 0) + 1;
      });
    }
    
    // Build leaderboard
    const leaderboard: LeaderboardEntry[] = [];
    
    for (const user of users) {
      const kudosCount = userKudosCounts[user.id] || 0;
      
      if (kudosCount > 0) {
        const valuesCounts = userTopValues[user.id] || {};
        const sortedValues = Object.entries(valuesCounts)
          .map(([valueId, count]) => ({ 
            value: this.values.get(parseInt(valueId))!,
            count
          }))
          .filter(entry => entry.value) // Filter out undefined values
          .sort((a, b) => b.count - a.count)
          .slice(0, 3); // Top 3 values
        
        leaderboard.push({
          user,
          kudosCount,
          topValues: sortedValues
        });
      }
    }
    
    // Sort by kudos count and limit
    return leaderboard
      .sort((a, b) => b.kudosCount - a.kudosCount)
      .slice(0, limit);
  }

  // Dashboard data
  async getUserStats(userId: number): Promise<UserStats> {
    // Current period
    const receivedKudos = await this.listUserReceivedKudos(userId);
    const givenKudos = await this.listUserGivenKudos(userId);
    const userBadges = await this.getUserBadges(userId);
    
    const now = new Date();
    const thirtyDaysAgo = new Date(now);
    thirtyDaysAgo.setDate(now.getDate() - 30);
    
    const sixtyDaysAgo = new Date(now);
    sixtyDaysAgo.setDate(now.getDate() - 60);
    
    // Current period stats
    const currentReceivedCount = receivedKudos.filter(
      k => k.createdAt >= thirtyDaysAgo
    ).length;
    
    const currentGivenCount = givenKudos.filter(
      k => k.createdAt >= thirtyDaysAgo
    ).length;
    
    const currentBadgesCount = userBadges.filter(
      b => b.earnedAt >= thirtyDaysAgo
    ).length;
    
    // Previous period stats
    const prevReceivedCount = receivedKudos.filter(
      k => k.createdAt >= sixtyDaysAgo && k.createdAt < thirtyDaysAgo
    ).length;
    
    const prevGivenCount = givenKudos.filter(
      k => k.createdAt >= sixtyDaysAgo && k.createdAt < thirtyDaysAgo
    ).length;
    
    const prevBadgesCount = userBadges.filter(
      b => b.earnedAt >= sixtyDaysAgo && b.earnedAt < thirtyDaysAgo
    ).length;
    
    // Calculate trends (percentage change)
    const calculateTrend = (current: number, previous: number) => {
      if (previous === 0) return current > 0 ? 100 : 0;
      return Math.round(((current - previous) / previous) * 100);
    };
    
    return {
      kudosReceived: receivedKudos.length,
      kudosGiven: givenKudos.length,
      badgesEarned: userBadges.length,
      receivedTrend: calculateTrend(currentReceivedCount, prevReceivedCount),
      givenTrend: calculateTrend(currentGivenCount, prevGivenCount),
      badgesTrend: calculateTrend(currentBadgesCount, prevBadgesCount)
    };
  }

  async getTeamEngagement(): Promise<number> {
    const users = await this.listUsers();
    const now = new Date();
    const thirtyDaysAgo = new Date(now);
    thirtyDaysAgo.setDate(now.getDate() - 30);
    
    let activeUsers = 0;
    
    for (const user of users) {
      const receivedKudos = await this.listUserReceivedKudos(user.id);
      const givenKudos = await this.listUserGivenKudos(user.id);
      
      const recentActivity = [...receivedKudos, ...givenKudos].some(
        k => k.createdAt >= thirtyDaysAgo
      );
      
      if (recentActivity) {
        activeUsers++;
      }
    }
    
    return Math.round((activeUsers / users.length) * 100);
  }
}

export const storage = new MemStorage();
