import { type ChatPostMessageArguments, WebClient, Block, KnownBlock } from "@slack/web-api";
import { insertKudosSchema, insertKudosValueSchema } from "@shared/schema";
import { z } from "zod";
import { storage } from "./storage";

if (process.env.NODE_ENV === "production" && !process.env.SLACK_BOT_TOKEN) {
  console.warn("Warning: SLACK_BOT_TOKEN environment variable is not set. Slack integration will not work.");
}

if (process.env.NODE_ENV === "production" && !process.env.SLACK_CHANNEL_ID) {
  console.warn("Warning: SLACK_CHANNEL_ID environment variable is not set. Slack kudos will not be posted to a channel.");
}

// Initialize Slack client if token is available
const slackToken = process.env.SLACK_BOT_TOKEN;
const slack = slackToken ? new WebClient(slackToken) : null;

/**
 * Parse a Slack kudos message and extract the username and message
 * Format: /kudos @username message #value1 #value2
 */
export async function parseSlackKudos(
  text: string,
  fromUsername: string
): Promise<{
  toUsername: string;
  message: string;
  valueNames: string[];
  success: boolean;
  error?: string;
}> {
  try {
    // Extract the recipient username (with @ symbol)
    const usernameMatch = text.match(/@(\w+)/);
    if (!usernameMatch) {
      return {
        toUsername: "",
        message: "",
        valueNames: [],
        success: false,
        error: "No recipient specified. Use format: /kudos @username message #value1 #value2",
      };
    }

    const toUsername = usernameMatch[1]; // Get the username without @
    
    // Extract hashtags for values
    const valueMatches = text.match(/#(\w+)/g) || [];
    const valueNames = valueMatches.map(tag => tag.substring(1)); // Remove # prefix
    
    // Remove the @username and #values from the text to get the message
    let message = text.replace(/@\w+/, "").trim();
    valueMatches.forEach(tag => {
      message = message.replace(tag, "").trim();
    });
    
    // Check if the sender is trying to give kudos to themselves
    if (toUsername === fromUsername) {
      return {
        toUsername: "",
        message: "",
        valueNames: [],
        success: false,
        error: "You cannot give kudos to yourself.",
      };
    }
    
    // Check if the message is not empty
    if (!message) {
      return {
        toUsername: "",
        message: "",
        valueNames: [],
        success: false,
        error: "Please include a message with your kudos.",
      };
    }

    return {
      toUsername,
      message,
      valueNames,
      success: true,
    };
  } catch (error) {
    console.error("Error parsing Slack kudos:", error);
    return {
      toUsername: "",
      message: "",
      valueNames: [],
      success: false,
      error: "Failed to parse your kudos. Please use format: /kudos @username message #value1 #value2",
    };
  }
}

/**
 * Process a kudos message from Slack and save it to the database
 */
export async function processSlackKudos(
  text: string,
  fromUsername: string
): Promise<{
  success: boolean;
  message: string;
  kudosId?: number;
}> {
  try {
    const { toUsername, message, valueNames, success, error } = await parseSlackKudos(text, fromUsername);
    
    if (!success) {
      return { success: false, message: error || "Failed to parse kudos" };
    }
    
    // Get or create the users
    const fromUser = await storage.getUserByUsername(fromUsername);
    const toUser = await storage.getUserByUsername(toUsername);
    
    if (!fromUser) {
      return { success: false, message: "Your user account is not registered in KudosConnect." };
    }
    
    if (!toUser) {
      return { success: false, message: `User @${toUsername} is not registered in KudosConnect.` };
    }
    
    // Create the kudos
    const kudosData = {
      fromUserId: fromUser.id,
      toUserId: toUser.id,
      message,
      isPublic: true,
      platform: "slack",
    };
    
    // Validate the kudos data
    const validatedData = insertKudosSchema.parse(kudosData);
    
    // Create the kudos
    const kudos = await storage.createKudos(validatedData);
    
    // Add values to the kudos
    for (const valueName of valueNames) {
      const value = await storage.getValueByName(valueName);
      if (value) {
        const kudosValue = {
          kudosId: kudos.id,
          valueId: value.id,
        };
        
        const validatedKudosValue = insertKudosValueSchema.parse(kudosValue);
        await storage.createKudosValue(validatedKudosValue);
      }
    }
    
    // Get the values to include in the message
    const kudosValues = await storage.getKudosValues(kudos.id);
    
    return {
      success: true,
      message: `Kudos from @${fromUser.username} to @${toUser.username} saved successfully!`,
      kudosId: kudos.id,
    };
  } catch (error) {
    console.error("Error processing Slack kudos:", error);
    return { success: false, message: "An error occurred while processing your kudos." };
  }
}

/**
 * Send a kudos message to a Slack channel
 */
export async function sendKudosToSlackChannel(kudosId: number): Promise<boolean> {
  if (!slack || !process.env.SLACK_CHANNEL_ID) {
    console.log("Slack integration not configured. Skipping post to Slack channel.");
    return false;
  }
  
  try {
    const kudosWithDetails = await storage.getKudosWithDetails(kudosId);
    
    if (!kudosWithDetails) {
      console.error(`Kudos with ID ${kudosId} not found`);
      return false;
    }
    
    // Format values as hashtags
    const valuesTags = kudosWithDetails.values.map(v => `#${v.name}`).join(" ");
    
    // Create the Slack message blocks
    const blocks: KnownBlock[] = [
      {
        type: "section",
        text: {
          type: "mrkdwn",
          text: `*:star: New Kudos!*\n${kudosWithDetails.fromUser.displayName} → ${kudosWithDetails.toUser.displayName}`,
        },
      },
      {
        type: "section",
        text: {
          type: "plain_text",
          text: kudosWithDetails.message,
        },
      },
    ];
    
    // Add values if there are any
    if (kudosWithDetails.values.length > 0) {
      blocks.push({
        type: "context",
        elements: [
          {
            type: "mrkdwn",
            text: valuesTags,
          },
        ],
      });
    }
    
    // Add divider
    blocks.push({
      type: "divider",
    });
    
    // Send the message
    await slack.chat.postMessage({
      channel: process.env.SLACK_CHANNEL_ID,
      blocks,
      text: `${kudosWithDetails.fromUser.displayName} gave kudos to ${kudosWithDetails.toUser.displayName}`,
    });
    
    return true;
  } catch (error) {
    console.error("Error sending kudos to Slack channel:", error);
    return false;
  }
}

/**
 * Handle a Slack slash command request
 */
export async function handleSlackSlashCommand(body: any): Promise<{ text: string, response_type?: string }> {
  try {
    console.log("Processing Slack slash command with body:", body);
    
    const text = body.text || "";
    const user_name = body.user_name || "";
    
    // Check if we have the required data
    if (!text) {
      return { 
        text: "Please provide a message. Format: `/kudos @username message #value1 #value2`",
        response_type: "ephemeral"
      };
    }
    
    const result = await processSlackKudos(text, user_name);
    
    if (result.success && result.kudosId) {
      // Send the kudos to the shared channel
      await sendKudosToSlackChannel(result.kudosId);
      return { 
        text: result.message,
        response_type: "ephemeral" // Only visible to the sender
      };
    }
    
    return { 
      text: result.message,
      response_type: "ephemeral" // Only visible to the sender
    };
  } catch (error) {
    console.error("Error handling Slack slash command:", error);
    return { 
      text: "An error occurred while processing your request. Please try again.",
      response_type: "ephemeral"
    };
  }
}
