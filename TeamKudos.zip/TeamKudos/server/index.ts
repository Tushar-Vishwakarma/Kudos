import express, { type Request, Response, NextFunction } from "express";
import { registerRoutes } from "./routes";
import { setupVite, serveStatic, log } from "./vite";

const app = express();

// Special handling for Slack's verification requests
app.use('/api/slack/events', (req, res, next) => {
  const rawBody: Buffer[] = [];
  
  req.on('data', (chunk) => {
    rawBody.push(chunk);
  });
  
  req.on('end', () => {
    try {
      const bodyString = Buffer.concat(rawBody).toString();
      console.log("Raw request body for Slack events:", bodyString);
      
      // Try to parse as JSON if it looks like JSON
      if (bodyString.trim().startsWith('{')) {
        try {
          req.body = JSON.parse(bodyString);
          console.log("Parsed JSON body:", req.body);
        } catch (e) {
          console.log("Failed to parse JSON body:", e);
        }
      }
      
      // Special check for Slack's URL verification
      if (req.body && req.body.type === 'url_verification') {
        console.log("Detected Slack URL verification challenge");
        return res.json({ challenge: req.body.challenge });
      }
      
      next();
    } catch (error) {
      console.error("Error processing Slack event request:", error);
      next();
    }
  });
});

// Setup normal request parsing for other routes
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use((req, res, next) => {
  const start = Date.now();
  const path = req.path;
  let capturedJsonResponse: Record<string, any> | undefined = undefined;

  const originalResJson = res.json;
  res.json = function (bodyJson, ...args) {
    capturedJsonResponse = bodyJson;
    return originalResJson.apply(res, [bodyJson, ...args]);
  };

  res.on("finish", () => {
    const duration = Date.now() - start;
    if (path.startsWith("/api")) {
      let logLine = `${req.method} ${path} ${res.statusCode} in ${duration}ms`;
      if (capturedJsonResponse) {
        logLine += ` :: ${JSON.stringify(capturedJsonResponse)}`;
      }

      if (logLine.length > 80) {
        logLine = logLine.slice(0, 79) + "…";
      }

      log(logLine);
    }
  });

  next();
});

(async () => {
  const server = await registerRoutes(app);

  app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
    const status = err.status || err.statusCode || 500;
    const message = err.message || "Internal Server Error";

    res.status(status).json({ message });
    throw err;
  });

  // importantly only setup vite in development and after
  // setting up all the other routes so the catch-all route
  // doesn't interfere with the other routes
  if (app.get("env") === "development") {
    await setupVite(app, server);
  } else {
    serveStatic(app);
  }

  // ALWAYS serve the app on port 5000
  // this serves both the API and the client.
  // It is the only port that is not firewalled.
  const port = 5000;
  server.listen({
    port,
    host: "0.0.0.0",
    reusePort: true,
  }, () => {
    log(`serving on port ${port}`);
  });
})();
