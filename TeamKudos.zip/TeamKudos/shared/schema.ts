import { pgTable, text, serial, integer, boolean, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  displayName: text("display_name").notNull(),
  avatarUrl: text("avatar_url"),
  department: text("department"),
  email: text("email"),
  isAdmin: boolean("is_admin").default(false),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
});

// Values (for recognition categories)
export const values = pgTable("values", {
  id: serial("id").primaryKey(),
  name: text("name").notNull().unique(),
  description: text("description"),
  icon: text("icon"), // FontAwesome icon class
  colorClass: text("color_class"), // Tailwind CSS color class
});

export const insertValueSchema = createInsertSchema(values).omit({
  id: true,
});

// Badges
export const badges = pgTable("badges", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  description: text("description"),
  icon: text("icon"), // FontAwesome icon class
  colorClass: text("color_class"), // Tailwind CSS color class
  requiredKudos: integer("required_kudos").default(5),
});

export const insertBadgeSchema = createInsertSchema(badges).omit({
  id: true,
});

// User Badges (junction table)
export const userBadges = pgTable("user_badges", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  badgeId: integer("badge_id").notNull(),
  level: integer("level").default(1),
  earnedAt: timestamp("earned_at").defaultNow(),
});

export const insertUserBadgeSchema = createInsertSchema(userBadges).omit({
  id: true,
  earnedAt: true,
});

// Kudos
export const kudos = pgTable("kudos", {
  id: serial("id").primaryKey(),
  fromUserId: integer("from_user_id").notNull(),
  toUserId: integer("to_user_id").notNull(),
  message: text("message").notNull(),
  isPublic: boolean("is_public").default(true),
  createdAt: timestamp("created_at").defaultNow(),
  platform: text("platform"), // "app", "slack", "teams"
});

export const insertKudosSchema = createInsertSchema(kudos).omit({
  id: true,
  createdAt: true,
});

// Kudos Values (junction table for tagging values in kudos)
export const kudosValues = pgTable("kudos_values", {
  id: serial("id").primaryKey(),
  kudosId: integer("kudos_id").notNull(),
  valueId: integer("value_id").notNull(),
});

export const insertKudosValueSchema = createInsertSchema(kudosValues).omit({
  id: true,
});

// Reactions to kudos
export const reactions = pgTable("reactions", {
  id: serial("id").primaryKey(),
  kudosId: integer("kudos_id").notNull(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // "like", "heart", "star"
});

export const insertReactionSchema = createInsertSchema(reactions).omit({
  id: true,
});

// Types
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Value = typeof values.$inferSelect;
export type InsertValue = z.infer<typeof insertValueSchema>;

export type Badge = typeof badges.$inferSelect;
export type InsertBadge = z.infer<typeof insertBadgeSchema>;

export type UserBadge = typeof userBadges.$inferSelect;
export type InsertUserBadge = z.infer<typeof insertUserBadgeSchema>;

export type Kudos = typeof kudos.$inferSelect;
export type InsertKudos = z.infer<typeof insertKudosSchema>;

export type KudosValue = typeof kudosValues.$inferSelect;
export type InsertKudosValue = z.infer<typeof insertKudosValueSchema>;

export type Reaction = typeof reactions.$inferSelect;
export type InsertReaction = z.infer<typeof insertReactionSchema>;
