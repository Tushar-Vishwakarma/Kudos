import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { SendKudosModal } from "@/components/kudos/send-kudos-modal";

export default function GiveKudos() {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTab, setSelectedTab] = useState("web");

  const { data: values } = useQuery({
    queryKey: ["/api/values"],
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold text-gray-900">Give Kudos</h1>
        <Button onClick={() => setIsModalOpen(true)}>
          <i className="fas fa-plus mr-2"></i>
          Send Kudos
        </Button>
      </div>

      <Tabs defaultValue="web" className="w-full" onValueChange={setSelectedTab}>
        <TabsList className="mb-4">
          <TabsTrigger value="web">Web App</TabsTrigger>
          <TabsTrigger value="slack">Slack</TabsTrigger>
          <TabsTrigger value="teams">Microsoft Teams</TabsTrigger>
        </TabsList>
        
        <TabsContent value="web" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Using the Web App</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>You can send kudos directly through this web app by clicking the "Send Kudos" button anywhere in the application.</p>
              <Button onClick={() => setIsModalOpen(true)} className="mt-4">
                <i className="fas fa-plus mr-2"></i>
                Send Kudos Now
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="slack" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Using Slack Integration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>Send kudos directly from Slack using the <code>/kudos</code> command.</p>
              
              <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
                <h3 className="font-medium mb-2">Syntax:</h3>
                <pre className="bg-gray-100 p-2 rounded text-sm">/kudos @username Great job on the project! #value1 #value2</pre>
                
                <h3 className="font-medium mt-4 mb-2">Example:</h3>
                <pre className="bg-gray-100 p-2 rounded text-sm">/kudos @sarah.chen Thanks for helping with the debugging! #teamwork #problemsolver</pre>
                
                <h3 className="font-medium mt-4 mb-2">Available Values:</h3>
                <div className="flex flex-wrap gap-2">
                  {values?.map((value: any) => (
                    <span key={value.id} className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-${value.colorClass}-100 text-${value.colorClass}-800`}>
                      <i className={`fas fa-${value.icon} mr-1`}></i> #{value.name}
                    </span>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
        
        <TabsContent value="teams" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Using Microsoft Teams Integration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p>Send kudos directly from Microsoft Teams using the <code>/kudos</code> command.</p>
              
              <div className="bg-gray-50 p-4 rounded-md border border-gray-200">
                <h3 className="font-medium mb-2">Syntax:</h3>
                <pre className="bg-gray-100 p-2 rounded text-sm">/kudos @username Great job on the project! #value1 #value2</pre>
                
                <h3 className="font-medium mt-4 mb-2">Example:</h3>
                <pre className="bg-gray-100 p-2 rounded text-sm">/kudos @miguel.rodriguez Excellent presentation yesterday! #excellence #leadership</pre>
                
                <h3 className="font-medium mt-4 mb-2">Available Values:</h3>
                <div className="flex flex-wrap gap-2">
                  {values?.map((value: any) => (
                    <span key={value.id} className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-${value.colorClass}-100 text-${value.colorClass}-800`}>
                      <i className={`fas fa-${value.icon} mr-1`}></i> #{value.name}
                    </span>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <SendKudosModal open={isModalOpen} onOpenChange={setIsModalOpen} />
    </div>
  );
}
