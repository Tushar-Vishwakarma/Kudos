import { useQuery } from "@tanstack/react-query";
import QuickStats from "@/components/dashboard/quick-stats";
import RecentActivity from "@/components/dashboard/recent-activity";
import LeaderboardWidget from "@/components/dashboard/leaderboard-widget";
import BadgesWidget from "@/components/dashboard/badges-widget";

export default function Dashboard() {
  // For demo purposes, we'll set a fixed user ID
  const currentUserId = 3; // Alex Morgan

  // Fetch user stats for the current user
  const { data: userStats, isLoading: isLoadingStats } = useQuery({
    queryKey: ["/api/users/" + currentUserId + "/stats"],
  });

  // Fetch team engagement
  const { data: teamEngagement, isLoading: isLoadingEngagement } = useQuery({
    queryKey: ["/api/team/engagement"],
  });

  // Fetch user badges
  const { data: userBadges, isLoading: isLoadingBadges } = useQuery({
    queryKey: ["/api/users/" + currentUserId + "/badges"],
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <QuickStats 
        isLoading={isLoadingStats || isLoadingEngagement} 
        stats={userStats} 
        teamEngagement={teamEngagement?.engagement} 
      />
      
      <RecentActivity />
      
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2">
          <LeaderboardWidget />
        </div>
        <div>
          <BadgesWidget isLoading={isLoadingBadges} userBadges={userBadges} />
        </div>
      </div>
    </div>
  );
}
