import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";

export default function MyBadges() {
  // For demo purposes, we'll set a fixed user ID
  const currentUserId = 3; // Alex Morgan
  
  const { data: userBadges, isLoading } = useQuery({
    queryKey: ["/api/users/" + currentUserId + "/badges"],
  });
  
  const { data: allBadges, isLoading: isLoadingAllBadges } = useQuery({
    queryKey: ["/api/badges"],
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900">My Recognition Badges</h1>
        <p className="text-gray-500">Badges are earned based on the kudos you receive.</p>
      </div>
      
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Earned Badges</CardTitle>
          <CardDescription>Badges you've unlocked through peer recognition</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {Array(4).fill(0).map((_, i) => (
                <div key={i} className="flex flex-col items-center p-4 rounded-lg border border-gray-200">
                  <Skeleton className="w-12 h-12 rounded-full mb-3" />
                  <Skeleton className="h-4 w-20 mb-1" />
                  <Skeleton className="h-3 w-16" />
                </div>
              ))}
            </div>
          ) : userBadges && userBadges.length > 0 ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
              {userBadges.map((userBadge: any) => (
                <div 
                  key={userBadge.id}
                  className="badge flex flex-col items-center justify-center p-3 rounded-lg border border-gray-200 hover:border-primary-300 hover:shadow-md cursor-pointer"
                >
                  <div className={`w-12 h-12 rounded-full bg-${userBadge.badge.colorClass}-100 flex items-center justify-center mb-2`}>
                    <i className={`fas fa-${userBadge.badge.icon} text-${userBadge.badge.colorClass}-600 text-xl`}></i>
                  </div>
                  <span className="text-sm font-medium text-gray-900">{userBadge.badge.name}</span>
                  <span className="text-xs text-gray-500">Level {userBadge.level}</span>
                </div>
              ))}
            </div>
          ) : (
            <div className="py-10 text-center text-gray-500">
              <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
                <i className="fas fa-award text-gray-400 text-2xl"></i>
              </div>
              <p>You haven't earned any badges yet.</p>
              <p className="text-sm mt-2">Badges are awarded based on the kudos you receive.</p>
            </div>
          )}
        </CardContent>
      </Card>
      
      <Card>
        <CardHeader>
          <CardTitle>Badges In Progress</CardTitle>
          <CardDescription>Keep receiving kudos to unlock these badges</CardDescription>
        </CardHeader>
        <CardContent>
          {isLoadingAllBadges ? (
            <div className="space-y-4">
              {Array(3).fill(0).map((_, i) => (
                <div key={i}>
                  <div className="flex items-center justify-between mb-1">
                    <Skeleton className="h-4 w-40" />
                    <Skeleton className="h-4 w-10" />
                  </div>
                  <Skeleton className="h-2 w-full" />
                </div>
              ))}
            </div>
          ) : (
            <div>
              {allBadges && userBadges ? (
                <div className="space-y-4">
                  {allBadges
                    .filter((badge: any) => !userBadges.some((ub: any) => ub.badge.id === badge.id))
                    .slice(0, 4)
                    .map((badge: any) => {
                      // For demo purposes - random progress
                      const progress = Math.floor(Math.random() * 4) + 1;
                      
                      return (
                        <div key={badge.id}>
                          <div className="flex items-center justify-between mb-1">
                            <div className="flex items-center">
                              <i className={`fas fa-${badge.icon} text-${badge.colorClass}-600 mr-2`}></i>
                              <span className="text-xs font-medium text-gray-700">{badge.name}</span>
                            </div>
                            <span className="text-xs text-gray-500">{progress}/{badge.requiredKudos}</span>
                          </div>
                          <Progress value={(progress / badge.requiredKudos) * 100} className="h-2" />
                        </div>
                      );
                    })
                  }
                  
                  {allBadges.length === userBadges.length && (
                    <div className="py-6 text-center text-gray-500">
                      <p>Congratulations! You've earned all available badges.</p>
                    </div>
                  )}
                </div>
              ) : (
                <div className="py-6 text-center text-gray-500">
                  <p>Loading badge progress...</p>
                </div>
              )}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
