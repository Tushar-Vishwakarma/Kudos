import { Button } from "@/components/ui/button";
import { Link, useLocation } from "wouter";

interface NavigationProps {
  onOpenKudosModal: () => void;
}

export default function Navigation({ onOpenKudosModal }: NavigationProps) {
  const [location] = useLocation();

  return (
    <nav className="bg-white border-b border-gray-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-12">
          <div className="flex">
            <div className="flex space-x-8">
              <Link href="/">
                <a className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  location === "/" 
                    ? "border-primary-500 text-primary-600" 
                    : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                }`}>
                  Dashboard
                </a>
              </Link>
              <Link href="/give-kudos">
                <a className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  location === "/give-kudos" 
                    ? "border-primary-500 text-primary-600" 
                    : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                }`}>
                  Give Kudos
                </a>
              </Link>
              <Link href="/leaderboard">
                <a className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  location === "/leaderboard" 
                    ? "border-primary-500 text-primary-600" 
                    : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                }`}>
                  Leaderboard
                </a>
              </Link>
              <Link href="/my-badges">
                <a className={`inline-flex items-center px-1 pt-1 border-b-2 text-sm font-medium ${
                  location === "/my-badges" 
                    ? "border-primary-500 text-primary-600" 
                    : "border-transparent text-gray-500 hover:border-gray-300 hover:text-gray-700"
                }`}>
                  My Badges
                </a>
              </Link>
            </div>
          </div>
          <div className="flex items-center">
            <div className="flex-shrink-0">
              <Button 
                onClick={onOpenKudosModal}
                className="relative inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-white shadow-sm"
              >
                <i className="fas fa-plus mr-2 -ml-1"></i>
                Send Kudos
              </Button>
            </div>
          </div>
        </div>
      </div>
    </nav>
  );
}
