import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useQuery } from "@tanstack/react-query";

interface HeaderProps {
  onOpenKudosModal: () => void;
}

export default function Header({ onOpenKudosModal }: HeaderProps) {
  // For demo purposes, we'll set a fixed user ID
  const currentUserId = 3; // Alex Morgan
  
  const { data: currentUser } = useQuery({
    queryKey: ["/api/users/" + currentUserId],
  });

  return (
    <header className="bg-white shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-2">
            <div className="w-10 h-10 bg-primary-500 rounded-lg flex items-center justify-center">
              <i className="fas fa-award text-white text-xl"></i>
            </div>
            <h1 className="text-xl font-bold text-primary-700">KudosConnect</h1>
          </div>
          <div className="flex items-center space-x-4">
            <button className="px-3 py-2 rounded-md text-sm font-medium text-primary-700 hover:bg-primary-50 transition-colors">
              <i className="fas fa-book-open mr-2"></i>Guide
            </button>
            <button className="px-3 py-2 rounded-md text-sm font-medium text-primary-700 hover:bg-primary-50 transition-colors">
              <i className="fas fa-cog mr-2"></i>Settings
            </button>
            <div className="relative">
              <button className="flex items-center space-x-2 focus:outline-none">
                <Avatar>
                  <AvatarImage 
                    src={currentUser?.avatarUrl || "https://github.com/shadcn.png"} 
                    alt={currentUser?.displayName || "User"} 
                  />
                  <AvatarFallback>
                    {currentUser?.displayName?.split(' ').map((n: string) => n[0]).join('') || 'U'}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium hidden md:inline-block">
                  {currentUser?.displayName || "User"}
                </span>
                <i className="fas fa-chevron-down text-xs text-gray-500"></i>
              </button>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
