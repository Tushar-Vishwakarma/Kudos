import { useState } from "react";
import { useForm } from "react-hook-form";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";

import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";

interface SendKudosModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SendKudosModal({ open, onOpenChange }: SendKudosModalProps) {
  const { toast } = useToast();
  const [selectedValues, setSelectedValues] = useState<number[]>([]);
  
  // For demo purposes, we'll set a fixed user ID
  const currentUserId = 3; // Alex Morgan

  // Fetch users for recipient selection
  const { data: users } = useQuery({
    queryKey: ["/api/users"],
  });

  // Fetch values for tagging
  const { data: values } = useQuery({
    queryKey: ["/api/values"],
  });

  // Form definition
  const form = useForm({
    defaultValues: {
      toUserId: "",
      message: "",
      isPublic: true,
    },
  });

  // Add kudos mutation
  const addKudos = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/kudos", {
        kudos: {
          fromUserId: currentUserId,
          toUserId: parseInt(data.toUserId),
          message: data.message,
          isPublic: data.isPublic,
        },
        valueIds: selectedValues,
      });
      return response.json();
    },
    onSuccess: () => {
      // Show success toast
      toast({
        title: "Kudos sent!",
        description: "Your recognition has been shared successfully.",
      });
      
      // Reset form
      form.reset();
      setSelectedValues([]);
      
      // Close modal
      onOpenChange(false);
      
      // Invalidate queries to refresh data
      queryClient.invalidateQueries({ queryKey: ["/api/kudos/recent"] });
      queryClient.invalidateQueries({ queryKey: ["/api/users/" + currentUserId + "/stats"] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to send kudos. Please try again.",
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: any) => {
    if (data.toUserId === currentUserId.toString()) {
      toast({
        title: "Error",
        description: "You cannot give kudos to yourself.",
        variant: "destructive",
      });
      return;
    }
    
    addKudos.mutate(data);
  };

  const toggleValue = (valueId: number) => {
    setSelectedValues(prev => 
      prev.includes(valueId)
        ? prev.filter(id => id !== valueId)
        : [...prev, valueId]
    );
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Send Kudos</DialogTitle>
          <DialogDescription>
            Recognize a teammate for their great work.
          </DialogDescription>
        </DialogHeader>
        
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
            <FormField
              control={form.control}
              name="toUserId"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Recipient</FormLabel>
                  <Select 
                    onValueChange={field.onChange} 
                    defaultValue={field.value}
                  >
                    <FormControl>
                      <SelectTrigger>
                        <SelectValue placeholder="Select team member" />
                      </SelectTrigger>
                    </FormControl>
                    <SelectContent>
                      {users?.map((user: any) => (
                        <SelectItem 
                          key={user.id} 
                          value={user.id.toString()}
                          disabled={user.id === currentUserId}
                        >
                          {user.displayName} ({user.department})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Message</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="What would you like to recognize them for?" 
                      rows={4}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />
            
            <div>
              <FormLabel>Values</FormLabel>
              <div className="flex flex-wrap gap-2 mt-2">
                {values?.map((value: any) => (
                  <Badge
                    key={value.id}
                    variant={selectedValues.includes(value.id) ? "default" : "outline"}
                    className={`cursor-pointer ${
                      selectedValues.includes(value.id) 
                        ? "bg-primary-100 text-primary-800 hover:bg-primary-200 border-primary-200" 
                        : ""
                    }`}
                    onClick={() => toggleValue(value.id)}
                  >
                    <i className={`fas fa-${value.icon} mr-1`}></i> {value.name}
                  </Badge>
                ))}
              </div>
            </div>
            
            <div className="flex space-x-3">
              <Button type="button" variant="outline" size="sm">
                <i className="far fa-smile mr-1"></i> Emoji
              </Button>
              <Button type="button" variant="outline" size="sm">
                <i className="fas fa-photo-video mr-1"></i> GIF
              </Button>
            </div>
            
            <FormField
              control={form.control}
              name="isPublic"
              render={({ field }) => (
                <FormItem className="flex flex-row items-start space-x-3 space-y-0 mt-2">
                  <FormControl>
                    <Checkbox
                      checked={field.value}
                      onCheckedChange={field.onChange}
                    />
                  </FormControl>
                  <div className="space-y-1 leading-none">
                    <FormLabel>Make this kudos visible to the team</FormLabel>
                    <p className="text-xs text-gray-500">
                      Private kudos are only visible to the recipient and managers
                    </p>
                  </div>
                </FormItem>
              )}
            />
            
            <DialogFooter className="mt-6">
              <Button 
                type="button" 
                variant="outline" 
                onClick={() => onOpenChange(false)}
              >
                Cancel
              </Button>
              <Button 
                type="submit"
                disabled={addKudos.isPending}
              >
                {addKudos.isPending ? "Sending..." : "Send Kudos"}
              </Button>
            </DialogFooter>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
