import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { formatDistanceToNow } from "date-fns";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";

interface KudosCardProps {
  kudos: any;
}

export default function KudosCard({ kudos }: KudosCardProps) {
  // For demo purposes, we'll set a fixed user ID
  const currentUserId = 3; // Alex Morgan
  
  // Add reactions to a kudos
  const addReaction = useMutation({
    mutationFn: async ({ kudosId, type }: { kudosId: number, type: string }) => {
      const response = await apiRequest("POST", `/api/kudos/${kudosId}/react`, {
        userId: currentUserId,
        type
      });
      return response.json();
    },
    onSuccess: (data, variables) => {
      // Invalidate the recent kudos query to refresh the data
      queryClient.invalidateQueries({ queryKey: ["/api/kudos/recent"] });
    }
  });

  // Format the date
  const formattedDate = kudos.createdAt 
    ? formatDistanceToNow(new Date(kudos.createdAt), { addSuffix: true })
    : "recently";

  const reactionCounts = kudos.reactions || {
    "like": 0,
    "heart": 0,
    "star": 0
  };

  return (
    <Card className="kudos-card mb-4 overflow-hidden">
      <CardContent className="px-6 py-5">
        <div className="flex items-start justify-between">
          <div className="flex">
            <div className="flex-shrink-0 mr-4">
              <Avatar className="h-12 w-12">
                <AvatarImage src={kudos.fromUser?.avatarUrl || "https://github.com/shadcn.png"} />
                <AvatarFallback>
                  {kudos.fromUser?.displayName?.split(' ').map((n: string) => n[0]).join('') || 'U'}
                </AvatarFallback>
              </Avatar>
            </div>
            <div>
              <div className="flex items-center">
                <h3 className="text-sm font-medium text-gray-900">{kudos.fromUser?.displayName}</h3>
                <span className="mx-2 text-gray-500">→</span>
                <h3 className="text-sm font-medium text-gray-900">{kudos.toUser?.displayName}</h3>
                <span className="ml-2">
                  <Badge variant="outline" className="bg-primary-100 text-primary-800 hover:bg-primary-200 border-primary-200">
                    <i className={`fas fa-code mr-1`}></i> {kudos.fromUser?.department}
                  </Badge>
                </span>
              </div>
              <p className="mt-1 text-sm text-gray-500">
                {kudos.message}
                {kudos.values && kudos.values.map((value: any) => (
                  <span key={value.id} className={`ml-1 text-${value.colorClass}-600`}>#{value.name}</span>
                ))}
              </p>
              <div className="mt-2 flex items-center space-x-1">
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-6 px-2 text-xs"
                  onClick={() => addReaction.mutate({ kudosId: kudos.id, type: "like" })}
                  disabled={addReaction.isPending}
                >
                  <i className="far fa-thumbs-up mr-1"></i> {reactionCounts.like || 0}
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-6 px-2 text-xs"
                  onClick={() => addReaction.mutate({ kudosId: kudos.id, type: "heart" })}
                  disabled={addReaction.isPending}
                >
                  <i className="far fa-heart mr-1"></i> {reactionCounts.heart || 0}
                </Button>
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="h-6 px-2 text-xs"
                  onClick={() => addReaction.mutate({ kudosId: kudos.id, type: "star" })}
                  disabled={addReaction.isPending}
                >
                  <i className="far fa-star mr-1"></i> {reactionCounts.star || 0}
                </Button>
              </div>
            </div>
          </div>
          <div className="flex-shrink-0 self-start ml-4">
            <span className="text-xs text-gray-500">{formattedDate}</span>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
