import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";

interface BadgesWidgetProps {
  isLoading: boolean;
  userBadges?: any[];
}

export default function BadgesWidget({ isLoading, userBadges }: BadgesWidgetProps) {
  // Fetch all badges to show badges in progress
  const { data: allBadges, isLoading: isLoadingAllBadges } = useQuery({
    queryKey: ["/api/badges"],
  });

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle>Your Recognition Badges</CardTitle>
      </CardHeader>
      
      <CardContent>
        {isLoading ? (
          <div className="grid grid-cols-2 gap-4">
            {Array(4).fill(0).map((_, i) => (
              <div key={i} className="flex flex-col items-center p-3 rounded-lg border border-gray-200">
                <Skeleton className="w-12 h-12 rounded-full mb-2" />
                <Skeleton className="h-4 w-20 mb-1" />
                <Skeleton className="h-3 w-16" />
              </div>
            ))}
          </div>
        ) : userBadges && userBadges.length > 0 ? (
          <div className="grid grid-cols-2 gap-4">
            {userBadges.map((userBadge) => (
              <div
                key={userBadge.id}
                className="badge flex flex-col items-center justify-center p-3 rounded-lg border border-gray-200 hover:border-primary-300 hover:shadow-md cursor-pointer"
              >
                <div className={`w-12 h-12 rounded-full bg-${userBadge.badge.colorClass}-100 flex items-center justify-center mb-2`}>
                  <i className={`fas fa-${userBadge.badge.icon} text-${userBadge.badge.colorClass}-600 text-xl`}></i>
                </div>
                <span className="text-sm font-medium text-gray-900">{userBadge.badge.name}</span>
                <span className="text-xs text-gray-500">Level {userBadge.level}</span>
              </div>
            ))}
          </div>
        ) : (
          <div className="py-6 text-center text-gray-500">
            <div className="w-12 h-12 mx-auto mb-3 bg-gray-100 rounded-full flex items-center justify-center">
              <i className="fas fa-award text-gray-400 text-xl"></i>
            </div>
            <p>No badges earned yet.</p>
            <p className="text-sm mt-1">Start receiving kudos to earn badges!</p>
          </div>
        )}
        
        <div className="mt-6">
          <h4 className="text-sm font-medium text-gray-900 mb-3">Badges In Progress</h4>
          
          {isLoadingAllBadges ? (
            <div className="space-y-3">
              <div>
                <div className="flex items-center justify-between mb-1">
                  <Skeleton className="h-4 w-40" />
                  <Skeleton className="h-4 w-10" />
                </div>
                <Skeleton className="h-2 w-full" />
              </div>
              <div>
                <div className="flex items-center justify-between mb-1">
                  <Skeleton className="h-4 w-40" />
                  <Skeleton className="h-4 w-10" />
                </div>
                <Skeleton className="h-2 w-full" />
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              {allBadges && userBadges ? (
                allBadges
                  .filter((badge: any) => !userBadges.some((ub: any) => ub.badge.id === badge.id))
                  .slice(0, 2)
                  .map((badge: any) => {
                    // For demo purposes - random progress
                    const progress = Math.floor(Math.random() * 4) + 1;
                    
                    return (
                      <div key={badge.id}>
                        <div className="flex items-center justify-between mb-1">
                          <span className="text-xs font-medium text-gray-700">{badge.name}</span>
                          <span className="text-xs text-gray-500">{progress}/{badge.requiredKudos}</span>
                        </div>
                        <Progress value={(progress / badge.requiredKudos) * 100} className="h-2" />
                      </div>
                    );
                  })
              ) : (
                <div className="py-2 text-center text-gray-500 text-sm">
                  <p>Loading badge progress...</p>
                </div>
              )}

              {allBadges && userBadges && userBadges.length === allBadges.length && (
                <div className="py-2 text-center text-gray-500 text-sm">
                  <p>You've earned all available badges!</p>
                </div>
              )}
            </div>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="border-t border-gray-200 px-5 py-4">
        <Link href="/my-badges">
          <Button variant="link" className="p-0 h-auto text-primary-600 hover:text-primary-500 text-sm font-medium">
            View All Badges
            <i className="fas fa-arrow-right ml-1"></i>
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
