import { useQuery } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";

export default function LeaderboardWidget() {
  const { data: leaderboard, isLoading } = useQuery({
    queryKey: ["/api/leaderboard", { period: "monthly", limit: 5 }],
  });

  return (
    <Card>
      <CardHeader className="pb-2">
        <div className="flex items-center justify-between">
          <CardTitle>Monthly Leaderboard</CardTitle>
          <Badge variant="outline" className="bg-primary-100 text-primary-800">
            {new Date().toLocaleString('default', { month: 'long' })} {new Date().getFullYear()}
          </Badge>
        </div>
      </CardHeader>
      
      <div className="px-5 py-3 text-sm font-medium text-gray-500 bg-gray-50">
        <div className="grid grid-cols-12 gap-2">
          <div className="col-span-1">#</div>
          <div className="col-span-5">Team Member</div>
          <div className="col-span-2 text-center">Kudos</div>
          <div className="col-span-4">Top Value</div>
        </div>
      </div>
      
      <CardContent className="p-0">
        <div className="divide-y divide-gray-200 max-h-96 overflow-y-auto">
          {isLoading ? (
            // Loading skeleton
            Array(5).fill(0).map((_, i) => (
              <div key={i} className="px-5 py-4">
                <div className="grid grid-cols-12 gap-2 items-center">
                  <div className="col-span-1">
                    <Skeleton className="h-6 w-6" />
                  </div>
                  <div className="col-span-5">
                    <div className="flex items-center">
                      <Skeleton className="h-8 w-8 rounded-full mr-3" />
                      <div>
                        <Skeleton className="h-4 w-32 mb-2" />
                        <Skeleton className="h-3 w-20" />
                      </div>
                    </div>
                  </div>
                  <div className="col-span-2 text-center">
                    <Skeleton className="h-6 w-10 mx-auto" />
                  </div>
                  <div className="col-span-4">
                    <Skeleton className="h-5 w-24" />
                  </div>
                </div>
              </div>
            ))
          ) : (
            leaderboard?.map((entry: any, index: number) => (
              <div key={entry.user.id} className="px-5 py-4 hover:bg-gray-50">
                <div className="grid grid-cols-12 gap-2 items-center">
                  <div className="col-span-1 font-medium text-gray-900">{index + 1}</div>
                  <div className="col-span-5">
                    <div className="flex items-center">
                      <img 
                        className="h-8 w-8 rounded-full mr-3" 
                        src={entry.user.avatarUrl || `https://ui-avatars.com/api/?name=${entry.user.displayName}&background=random`} 
                        alt={entry.user.displayName} 
                      />
                      <div>
                        <div className="font-medium text-gray-900">{entry.user.displayName}</div>
                        <div className="text-xs text-gray-500">{entry.user.department}</div>
                      </div>
                    </div>
                  </div>
                  <div className="col-span-2 text-center">
                    <span className="inline-flex items-center justify-center w-10 h-6 bg-primary-100 text-primary-800 rounded-full text-sm font-medium">
                      {entry.kudosCount}
                    </span>
                  </div>
                  <div className="col-span-4">
                    {entry.topValues.length > 0 ? (
                      <>
                        <Badge className={`bg-${entry.topValues[0].value.colorClass}-100 text-${entry.topValues[0].value.colorClass}-800 border-${entry.topValues[0].value.colorClass}-200`}>
                          <i className={`fas fa-${entry.topValues[0].value.icon} mr-1`}></i> {entry.topValues[0].value.name}
                        </Badge>
                        {entry.topValues.length > 1 && (
                          <span className="ml-2 text-xs text-gray-500">+{entry.topValues.length - 1} others</span>
                        )}
                      </>
                    ) : (
                      <span className="text-xs text-gray-500">No values</span>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
          
          {!isLoading && (!leaderboard || leaderboard.length === 0) && (
            <div className="px-5 py-10 text-center text-gray-500">
              No data available for this period
            </div>
          )}
        </div>
      </CardContent>
      
      <CardFooter className="border-t border-gray-200 px-5 py-4">
        <Link href="/leaderboard">
          <Button variant="link" className="p-0 h-auto text-primary-600 hover:text-primary-500 text-sm font-medium">
            View Complete Leaderboard
            <i className="fas fa-arrow-right ml-1"></i>
          </Button>
        </Link>
      </CardFooter>
    </Card>
  );
}
