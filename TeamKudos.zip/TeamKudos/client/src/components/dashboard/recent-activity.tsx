import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import KudosCard from "@/components/kudos/kudos-card";
import { Skeleton } from "@/components/ui/skeleton";

export default function RecentActivity() {
  const [limit, setLimit] = useState(3);
  const [filter, setFilter] = useState("all");
  
  const { data: recentKudos, isLoading } = useQuery({
    queryKey: ["/api/kudos/recent", { limit, filter }],
  });

  return (
    <div className="mb-8">
      <div className="flex items-center justify-between mb-5">
        <h2 className="text-lg font-medium text-gray-900">Recent Kudos Activity</h2>
        <div className="flex space-x-3">
          <Button variant="ghost" size="sm" className="text-sm font-medium text-primary-600 hover:text-primary-500">
            <i className="fas fa-filter mr-1"></i> Filter
          </Button>
          <Select defaultValue="all" onValueChange={setFilter}>
            <SelectTrigger className="h-9 w-[160px]">
              <SelectValue placeholder="All Departments" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Departments</SelectItem>
              <SelectItem value="engineering">Engineering</SelectItem>
              <SelectItem value="marketing">Marketing</SelectItem>
              <SelectItem value="product">Product</SelectItem>
              <SelectItem value="design">Design</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {isLoading ? (
        // Loading skeleton
        Array(3).fill(0).map((_, i) => (
          <div key={i} className="bg-white shadow rounded-lg mb-4 overflow-hidden">
            <div className="px-6 py-5">
              <div className="flex">
                <Skeleton className="h-12 w-12 rounded-full mr-4" />
                <div className="w-full">
                  <div className="flex items-center mb-2">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-4 w-24 mx-2" />
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-5 w-20 ml-auto" />
                  </div>
                  <Skeleton className="h-4 w-full mb-1" />
                  <Skeleton className="h-4 w-3/4 mb-4" />
                  <div className="flex space-x-2">
                    <Skeleton className="h-6 w-16" />
                    <Skeleton className="h-6 w-16" />
                    <Skeleton className="h-6 w-16" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))
      ) : (
        <>
          {recentKudos?.map((kudos: any) => (
            <KudosCard key={kudos.id} kudos={kudos} />
          ))}
          
          {(!recentKudos || recentKudos.length === 0) && (
            <div className="bg-white shadow rounded-lg p-8 text-center text-gray-500">
              <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-award text-gray-400 text-2xl"></i>
              </div>
              <p className="mb-2">No kudos activity yet.</p>
              <p className="text-sm">Be the first to recognize a teammate!</p>
            </div>
          )}
        </>
      )}

      <Button 
        variant="outline" 
        className="w-full mt-2"
        onClick={() => setLimit(prev => prev === 3 ? 10 : 3)}
      >
        {limit === 3 ? "View More Activity" : "View Less Activity"}
      </Button>
    </div>
  );
}
