import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";

interface QuickStatsProps {
  isLoading: boolean;
  stats?: {
    kudosReceived: number;
    kudosGiven: number;
    badgesEarned: number;
    receivedTrend: number;
    givenTrend: number;
    badgesTrend: number;
  };
  teamEngagement?: number;
}

export default function QuickStats({ isLoading, stats, teamEngagement }: QuickStatsProps) {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 lg:grid-cols-4 mb-8">
      <Card>
        <CardContent className="p-6">
          {isLoading ? (
            <div className="space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-9 w-16 mt-1" />
              <Skeleton className="h-4 w-24 mt-2" />
            </div>
          ) : (
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">
                Kudos Received
              </dt>
              <dd className="mt-1 text-3xl font-semibold text-primary-600">
                {stats?.kudosReceived || 0}
              </dd>
              <dd className={`mt-2 text-sm flex items-center ${
                (stats?.receivedTrend || 0) > 0 
                  ? 'text-success' 
                  : (stats?.receivedTrend || 0) < 0 
                    ? 'text-error' 
                    : 'text-gray-500'
              }`}>
                {(stats?.receivedTrend || 0) > 0 ? (
                  <><i className="fas fa-arrow-up mr-1"></i> {stats?.receivedTrend}% from last month</>
                ) : (stats?.receivedTrend || 0) < 0 ? (
                  <><i className="fas fa-arrow-down mr-1"></i> {Math.abs(stats?.receivedTrend || 0)}% from last month</>
                ) : (
                  <><i className="fas fa-equals mr-1"></i> Same as last month</>
                )}
              </dd>
            </dl>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          {isLoading ? (
            <div className="space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-9 w-16 mt-1" />
              <Skeleton className="h-4 w-24 mt-2" />
            </div>
          ) : (
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">
                Kudos Given
              </dt>
              <dd className="mt-1 text-3xl font-semibold text-secondary-500">
                {stats?.kudosGiven || 0}
              </dd>
              <dd className={`mt-2 text-sm flex items-center ${
                (stats?.givenTrend || 0) > 0 
                  ? 'text-success' 
                  : (stats?.givenTrend || 0) < 0 
                    ? 'text-error' 
                    : 'text-gray-500'
              }`}>
                {(stats?.givenTrend || 0) > 0 ? (
                  <><i className="fas fa-arrow-up mr-1"></i> {stats?.givenTrend}% from last month</>
                ) : (stats?.givenTrend || 0) < 0 ? (
                  <><i className="fas fa-arrow-down mr-1"></i> {Math.abs(stats?.givenTrend || 0)}% from last month</>
                ) : (
                  <><i className="fas fa-equals mr-1"></i> Same as last month</>
                )}
              </dd>
            </dl>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          {isLoading ? (
            <div className="space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-9 w-16 mt-1" />
              <Skeleton className="h-4 w-24 mt-2" />
            </div>
          ) : (
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">
                Team Engagement
              </dt>
              <dd className="mt-1 text-3xl font-semibold text-success">
                {teamEngagement || 0}%
              </dd>
              <dd className="mt-2 text-sm text-success flex items-center">
                <i className="fas fa-users mr-1"></i> Active team participation
              </dd>
            </dl>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-6">
          {isLoading ? (
            <div className="space-y-2">
              <Skeleton className="h-4 w-32" />
              <Skeleton className="h-9 w-16 mt-1" />
              <Skeleton className="h-4 w-24 mt-2" />
            </div>
          ) : (
            <dl>
              <dt className="text-sm font-medium text-gray-500 truncate">
                Badges Earned
              </dt>
              <dd className="mt-1 text-3xl font-semibold text-primary-600">
                {stats?.badgesEarned || 0}
              </dd>
              <dd className={`mt-2 text-sm flex items-center ${
                (stats?.badgesTrend || 0) > 0 
                  ? 'text-success' 
                  : (stats?.badgesTrend || 0) < 0 
                    ? 'text-error' 
                    : 'text-gray-500'
              }`}>
                {(stats?.badgesTrend || 0) > 0 ? (
                  <><i className="fas fa-plus mr-1"></i> {stats?.badgesTrend > 100 ? 'New this month' : `${stats?.badgesTrend}% from last month`}</>
                ) : (stats?.badgesTrend || 0) < 0 ? (
                  <><i className="fas fa-minus mr-1"></i> No change from last month</>
                ) : (
                  <><i className="fas fa-equals mr-1"></i> Same as last month</>
                )}
              </dd>
            </dl>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
