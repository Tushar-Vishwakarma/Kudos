import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import GiveKudos from "@/pages/give-kudos";
import Leaderboard from "@/pages/leaderboard";
import MyBadges from "@/pages/my-badges";
import Header from "@/components/layout/header";
import Navigation from "@/components/layout/navigation";
import Footer from "@/components/layout/footer";
import { SendKudosModal } from "@/components/kudos/send-kudos-modal";
import { useState } from "react";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Dashboard} />
      <Route path="/give-kudos" component={GiveKudos} />
      <Route path="/leaderboard" component={Leaderboard} />
      <Route path="/my-badges" component={MyBadges} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [isKudosModalOpen, setIsKudosModalOpen] = useState(false);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <div className="min-h-screen flex flex-col bg-gray-50">
          <Header onOpenKudosModal={() => setIsKudosModalOpen(true)} />
          <Navigation onOpenKudosModal={() => setIsKudosModalOpen(true)} />
          <main className="flex-grow pb-10">
            <Router />
          </main>
          <Footer />
          <Toaster />
          <SendKudosModal open={isKudosModalOpen} onOpenChange={setIsKudosModalOpen} />
        </div>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
